import { Component } from '@angular/core';

@Component({
  selector: 'app-step5',
  templateUrl: './step5.component.html',
})
export class Step5Component {
  constructor() {}
}
