import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-main-modal',
  templateUrl: './main-modal.component.html',
})
export class MainModalComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
