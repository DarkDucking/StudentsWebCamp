import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-upgrade-plan-modal',
  templateUrl: './upgrade-plan-modal.component.html',
})
export class UpgradePlanModalComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
